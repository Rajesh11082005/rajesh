use DeccanAir;

DESCRIBE customer
