use DeccanAir;
create table flights(F_no varchar(4),Takeoff_Time varchar(5),Landing_Time varchar(5),Fare bigint);

insert into flights values("F001","7:00","8:30",3000);
insert into flights values("F002","16:00","17:30",3000);
insert into flights values('F003','1:00','4:30',7000);
insert into flights values('F004','18:00','21:30',7000);
insert into flights values('F005','10:00','13:00',9000);
insert into flights values('F006','19:00','23:00',9000);

insert into flights values("F002","7:00","8:30",3000);
insert into flights values("F001","16:00","17:30",3000);
insert into flights values('F008','9:30','14:30',10000);
insert into flights values('F007','17:30','22:30',10000);
insert into flights values('F010','3:00','8:30',11000);
insert into flights values('F009','15:30','21:00',11000);

insert into flights values('F004','1:00','4:30',7000);
insert into flights values('F003','18:00','21:30',7000);
insert into flights values('F007','9:30','14:30',10000);
insert into flights values('F008','17:30','22:30',10000);
insert into flights values('F012','8:00','12:45',8000);
insert into flights values('F011','18:00','22:45',8000);

insert into flights values('F006','10:00','13:00',9000);
insert into flights values('F005','19:00','23:00',9000);
insert into flights values('F009','3:00','8:30',11000);
insert into flights values('F010','15:30','21:00',11000);
insert into flights values('F011','8:00','12:45',8000);
insert into flights values('F012','18:00','22:45',8000);