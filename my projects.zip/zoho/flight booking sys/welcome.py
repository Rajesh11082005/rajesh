from tkinter import *
from tkinter import ttk
from tkinter.font import BOLD,ITALIC
from tkinter import messagebox
from PIL import Image,ImageTk
#import mysql.connector

def ticket(fno,n,ad,se,tf,f,t,takeoff,landing):
    wi=Toplevel()
    wi.geometry('1270x700+10+50')
    wi.resizable(0,0)
    wi.title('Ticket')
    imgf=Image.open('ticket.png')
    imgf=imgf.resize((1270,700))
    img=ImageTk.PhotoImage(imgf)
    llb=Label(wi,image=img,bg='black')
    llb.place(x=0,y=0,width=1270,height=700)
    
    Label(llb,text=f+' To '+t,font=('Agrandir Grand Medium',20,ITALIC,BOLD),width=20,bg='#2970db',fg='black').place(x=630,y=290)
    
    Label(llb,text=str(fno),font=('Agrandir Grand Medium',15,BOLD),width=20,bg='#2970db',fg='black').place(x=690,y=354)
    
    Label(llb,text=n,font=('Agrandir Grand Medium',15,BOLD),width=17,bg='#2970db',fg='black').place(x=770,y=405)
    
    Label(llb,text=str(ad),font=('Agrandir Grand Medium',15,BOLD),width=20,bg='#2970db',fg='black').place(x=680,y=458)
    
    Label(llb,text=str(se),font=('Agrandir Grand Medium',15,BOLD),width=12,bg='#2970db',fg='black').place(x=720,y=512)
    
    Label(llb,text='Rs.'+str(tf),font=('Agrandir Grand Medium',15,BOLD),width=12,bg='#2970db',fg='black').place(x=1040,y=542)
    
    Label(llb,text=takeoff+' - '+landing,font=('Agrandir Grand Medium',15,BOLD),width=12,bg='#2970db',fg='black').place(x=1030,y=300)
    
    wi.mainloop()


def ticketbooking(f,t,fno,n,takeoff,landing,fare):
    
    def book():
        conn=mysql.connector.connect(host='localhost',user='mysqluser',password='root',database='DeccanAir')
        if sen.get()=='' or aen.get()=='' or payment.get()==0:
            messagebox.showerror('Error','All fields are required')
            
        else:
            mcur=conn.cursor()
            q=f"insert into customer values('{n}','{fno}','{f}','{t}','{takeoff}','{landing}','{aen.get()}',{int(sen.get())},{int(fare)},{fare*int(sen.get())},'{'Online Transaction' if payment.get()==1 else 'Pay on counter'}');"
            mcur.execute(q)
            ticket(fno,n,aen.get(),sen.get(),fare*int(sen.get()),f,t,takeoff,landing)
        conn.commit()
        conn.close()
    
    
    w=Toplevel()
    w.geometry('1270x700+10+50')
    w.resizable(0,0)
    w.title('Ticket Booking')
    imgf=Image.open('ticket booking.png')
    imgf=imgf.resize((1270,700))
    img=ImageTk.PhotoImage(imgf)
    llb=Label(w,image=img,bg='black')
    llb.place(x=0,y=0,width=1270,height=700)
    
    Label(llb,text=f+' To '+t,font=('Agrandir Grand Medium',20,ITALIC,BOLD),width=20,bg='#8cc2ef',fg='black').place(x=465,y=200)
    
    Label(llb,text='Flight No. '+fno,font=('Agrandir Grand Medium',20),width=20,bg='#8cc2ef',fg='black').place(x=310,y=260)
    
    Label(llb,text='No.of seats ',font=('Agrandir Grand Medium',20),width=20,bg='#8cc2ef',fg='black').place(x=288,y=320)
    
    sen=Entry(llb,font=('Open Sauce',14),bd=0,width=10,bg='white',fg='black')
    sen.place(x=580,y=325)
    
    Label(llb,text='Aadhar No.',font=('Agrandir Grand Medium',20),width=20,bg='#8cc2ef',fg='black').place(x=288,y=380)
    
    aen=Entry(llb,font=('Open Sauce',14),bd=0,width=10,bg='white',fg='black')
    aen.place(x=580,y=385)
    
    Label(llb,text='Payment methoed',font=('Agrandir Grand Medium',20),width=20,bg='#8cc2ef',fg='black').place(x=475,y=440)
    
    #radio button
    payment=IntVar()
    orb=Radiobutton(llb,text='Online transaction',activebackground='#8cc2ef',variable=payment,value=1,font=('Agrandir Grand Medium',15),bg='#8cc2ef',fg='black',bd=0)
    orb.place(x=430,y=490)
    
    crb=Radiobutton(llb,text='Pay on counter',activebackground='#8cc2ef',variable=payment,value=2,font=('Agrandir Grand Medium',15),bg='#8cc2ef',fg='black',bd=0)
    crb.place(x=680,y=490)
    
    Bookbt=Button(llb,text='Book',font=('Open Sauce',20),command=book,height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
    Bookbt.place(x=530,y=560)
    
    w.mainloop()

def mainpg(k):
    def search():
        
        if fromcmb.get()=='' and tocmb.get()=='':
            messagebox.showerror('Error','Choose the location',parent=root)
  
        elif fromcmb.get()==tocmb.get():
            messagebox.showerror('Error','Invaild Location',parent=root)
        
        elif fromcmb.get()=='Chennai' and tocmb.get()=='Mumbai':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Chennai','Mumbai','F001',kk[0],'7:00','8:30',3000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__0_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Chennai','Mumbai','F002',kk[0],'16:00','17:30',3000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__2_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Mumbai' and tocmb.get()=='Chennai':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Mumbai','Chennai','F002',kk[0],'7:00','8:30',3000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__1_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Mumbai','Chennai','F001',kk[0],'16:00','17:30',3000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__3_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Chennai' and tocmb.get()=='Kolkata':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Chennai','Kolkata','F003',kk[0],'1:00','4:30',7000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__4_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Chennai','Kolkata','F004',kk[0],'18:00','21:30',7000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__6_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Kolkata' and tocmb.get()=='Chennai':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Kolkata','Chennai','F004',kk[0],'1:00','4:30',7000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__5_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Kolkata','Chennai','F003',kk[0],'18:00','21:30',7000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__7_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Chennai' and tocmb.get()=='Delhi':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Chennai','Delhi','F005',kk[0],'10:00','13:00',9000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__8_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Chennai','Delhi','F006',kk[0],'19:00','23:00',9000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__10_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
        
        elif fromcmb.get()=='Delhi' and tocmb.get()=='Chennai':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Delhi','Chennai','F006',kk[0],'10:00','13:00',9000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__9_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Delhi','Chennai','F005',kk[0],'19:00','23:00',9000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__11_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Mumbai' and tocmb.get()=='Kolkata':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Mumbai','Kolakata','F007',kk[0],'9:30','14:30',10000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__12_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Mumbai','Kolakata','F008',kk[0],'17:30','22:30',10000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__14_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Kolkata' and tocmb.get()=='Mumbai':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Kolakata','Mumbai','F008',kk[0],'9:30','14:30',10000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__13_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Kolakata','Mumbai','F007',kk[0],'17:30','22:30',10000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__15_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
        
        elif fromcmb.get()=='Mumbai' and tocmb.get()=='Delhi':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Mumbai','Delhi','F009',kk[0],'3:00','8:30',11000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__16_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Mumbai','Delhi','F010',kk[0],'15:30','21:00',11000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__18_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Delhi' and tocmb.get()=='Mumbai':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Delhi','Mumbai','F010',kk[0],'3:00','8:30',11000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__17_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Delhi','Mumbai','F009',kk[0],'15:30','21:00',11000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__19_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
        elif fromcmb.get()=='Kolkata' and tocmb.get()=='Delhi':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Kolkata','Delhi','F011',kk[0],'8:00','12:45',8000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__20_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Kolkata','Delhi','F012',kk[0],'18:00','22:40',8000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__22_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
        
        elif fromcmb.get()=='Delhi' and tocmb.get()=='Kolkata':
            def c():
                bt1.config(image=imgg)
                bt1.config(command=ticketbooking('Delhi','Kolkata','F012',kk[0],'8:00','12:45',8000))
                
            imgg=PhotoImage(file='pro//Blue_Travel_Offers___Deals_Website__21_-removebg-preview.png')
            bt1=Button(fra,command=c,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt1.config(image=imgg)
            bt1.place(x=55,y=20,width=914,height=126)
            
            def d():
                bt2.config(image=imggg)
                bt2.config(command=ticketbooking('Delhi','Kolkata','F011',kk[0],'18:00','22:40',8000))
                
            ik=Image.open('pro//Blue_Travel_Offers___Deals_Website__23_-removebg-preview.png')
            imggg=ImageTk.PhotoImage(ik)
            bt2=Button(fra,command=d,bd=0,bg='white',activebackground='white',cursor='hand2')
            bt2.config(image=imggg)
            bt2.place(x=55,y=150,width=914,height=126)
            
            
    root=Toplevel()
    root.geometry('1270x700+10+50')
    root.resizable(0,0)
    root.title('Flight Booking')
    
    imgf=Image.open('mainpg.png')
    imgf=imgf.resize((1270,700))
    img=ImageTk.PhotoImage(imgf)
    llb=Label(root,image=img,bg='black')
    llb.place(x=0,y=0,width=1270,height=700)
    
    fra=Frame(root,height=370,width=1030,bg='white')
    fra.place(x=120,y=274)
    
    conn=mysql.connector.connect(host='localhost',user='mysqluser',password='root',database='DeccanAir')
    mcur=conn.cursor()
    q='select Name from useraccounts where Email=%s'
    val=(k,)
    mcur.execute(q,val)
    kk=mcur.fetchone()
    
    Label(llb,text=kk[0],bg='#2970db',fg='white',font=('Agrandir Grand Medium',35)).place(x=645,y=45)
    
    searchbt=Button(llb,text='Search',font=('Agrandir Grand Medium',20),command=search,height=1,width=10,bg='#2970db',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
    searchbt.place(x=965,y=160)
    
    fromcmb=ttk.Combobox(llb,font=('Agrandir Grand Medium',20),width=20,state='readonly')
    fromcmb['value']=(
        'Chennai',
        'Kolkata',
        'Mumbai',
        'Delhi'
    )
    fromcmb.set('')
    fromcmb.place(x=120,y=190)

    tocmb=ttk.Combobox(llb,font=('Agrandir Grand Medium',20,),width=20,state='readonly')
    tocmb['value']=(
        'Chennai',
        'Kolkata',
        'Mumbai',
        'Delhi'
    )
    tocmb.set('')
    tocmb.place(x=570,y=190)
    
    root.mainloop()
    
    
def Signup():
    def submit():
        if nen.get()=='Name' or emailen.get()=='Email' or pasen.get()=='Password':
            messagebox.showerror('Error!','All details are required to be filled',parent=root2)
        elif pasen.get()=='Confirm password':
            messagebox.showerror('Error!','Create a password!',parent=root2)
        elif len(pasen.get())<8 and len(pasen.get())<16:
            messagebox.showerror('Error!','Password should have minimum 8 characters and maximum 16 characters',parent=root2)
        elif emailen.get().count('@')!=1:
            messagebox.showerror('Error!','Invaild email',parent=root2)
        else:
            messagebox.showinfo('Account created','Successfully created an account',parent=root2)
            conn=mysql.connector.connect(host='localhost',user='mysqluser',password='root',database='DeccanAir')
            mcur=conn.cursor()
            q='select * from useraccounts where Email=%s'
            rr=emailen.get()
            val=(rr,)
            mcur.execute(q,val)
            row=mcur.fetchone()
            if row!=None:
                messagebox.showerror('Error','User already exist please try another email',parent=root2)
            else:
                mcur.execute(f"insert into useraccounts values('{nen.get()}','{emailen.get()}','{pasen.get()}')")
            conn.commit()
            conn.close()
            messagebox.showinfo('Account created','Successfully created an account',parent=root2)
    
    root2=Toplevel()
    root2.geometry('1250x700+10+50')
    root2.resizable(0,0)
    root2.title('Sign up')
    
    imgf=Image.open('signup.png')
    imgf=imgf.resize((1270,700))
    img=ImageTk.PhotoImage(imgf)
    llb=Label(root2,image=img,bg='black')
    llb.place(x=0,y=0,width=1270,height=700)
    
    def on_enter(e):
        if nen.get()=='Name':
            nen.delete(0,'end')
        
    def on_leave(e):
        name=nen.get()
        if name=='':
            name=nen.insert(0,'Name')
    
    nen=Entry(llb,font=('Open Sauce',23),bd=0,bg='white',fg='black')
    nen.insert(0,'Name')
    nen.place(x=150,y=200)
    nen.bind('<FocusIn>',on_enter)
    nen.bind('<FocusOut>',on_leave)
    
    def on_enter(e):
        if emailen.get()=='E-mail Id':
            emailen.delete(0,'end')
        
    def on_leave(e):
        name=emailen.get()
        if name=='':
            name=emailen.insert(0,'E-mail Id')
    
    emailen=Entry(llb,font=('Open Sauce',23),bd=0,bg='white',fg='black')
    emailen.insert(0,'E-mail Id')
    emailen.place(x=150,y=300)
    emailen.bind('<FocusIn>',on_enter)
    emailen.bind('<FocusOut>',on_leave)
    
    def on_enter(e):
        if pasen.get()=='Password':
            pasen.delete(0,'end')
        
    def on_leave(e):
        name=pasen.get()
        if name=='':
            name=pasen.insert(0,'Password')
    
    pasen=Entry(llb,font=('Open Sauce',23),bd=0,bg='white',fg='black')
    pasen.insert(0,'Password')
    pasen.place(x=150,y=400)
    pasen.bind('<FocusIn>',on_enter)
    pasen.bind('<FocusOut>',on_leave)
    
    signupbt=Button(llb,text='Sign up',command=submit,font=('Open Sauce',20),height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
    signupbt.place(x=220,y=500)
    
    
    root2.mainloop()
    
    

def Signin():
    root=Toplevel()

    root.geometry('1250x700+10+50')
    root.resizable(0,0)
    root.title('Sign in')
    
    imgf=Image.open('signin.png')
    imgf=imgf.resize((1270,700))
    img=ImageTk.PhotoImage(imgf)
    llb=Label(root,image=img,bg='black')
    llb.place(x=0,y=0,width=1270,height=700)
    
    def on_enter(e):
        if emen.get()=='E-mail Id':
            emen.delete(0,'end')
        
    def on_leave(e):
        name=emen.get()
        if name=='':
            name=emen.insert(0,'E-mail Id')
    
    emen=Entry(llb,font=('Open Sauce',23),bd=0,bg='white',fg='black')
    emen.insert(0,'E-mail Id')
    emen.place(x=790,y=200)
    emen.bind('<FocusIn>',on_enter)
    emen.bind('<FocusOut>',on_leave)
    
    def on_enter(e):
        if pen.get()=='Password':
            pen.delete(0,'end')
        
    def on_leave(e):
        name=pen.get()
        if name=='':
            name=pen.insert(0,'Password')
    
    pen=Entry(llb,font=('Open Sauce',23),bd=0,bg='white',fg='black')
    pen.insert(0,'Password')
    pen.place(x=790,y=300)
    pen.bind('<FocusIn>',on_enter)
    pen.bind('<FocusOut>',on_leave)
    
    def login():
        rk=emen.get()
        if emen.get()=='E-mail Id' or pen.get()=='Password':
            messagebox.showerror('Error','E-mail Id and Password should be filled',parent=root)
        elif emen.get().count('@')!=1:
            messagebox.showerror('Error','Invaild E-mail id',parent=root)
        else:
            conn=mysql.connector.connect(host='localhost',user='mysqluser',password='root',database='DeccanAir')
            mcur=conn.cursor() 
            mcur.execute(f"select * from useraccounts where Email='{emen.get()}' and Passwrd='{pen.get()}'")
            r=mcur.fetchone()
            if r==None:
                messagebox.showerror('Error','Invalid Username and Password',parent=root)
            else:
                mainpg(rk)
            conn.commit()
            conn.close()
    
    signinbt=Button(llb,text='Sign in',command=login,font=('Open Sauce',20),height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
    signinbt.place(x=860,y=400)
    
    Label(llb,text='Do you have an account?',fg='black',bg='#C4E1EF',font=('Open Sauce',12)).place(x=830,y=500)
    
    Button(llb,text='Sign up',fg='#0080fe',command=Signup,bg='#C4E1EF',bd=0,font=('Open Sauce',12,UNDERLINE),activebackground='#C4E1EF',cursor='hand2',activeforeground='#0080fe').place(x=1007,y=498)
    
    root.mainloop()

def Welcome():
    
    def a():
        win=Toplevel()

        win.geometry('1270x700+0+50')
        win.resizable(0,0)
        win.title('Reviews')
                
        imgf=Image.open('Testimonials.png')
        imgf=imgf.resize((1270,700))
        img=ImageTk.PhotoImage(imgf)
        llb=Label(win,image=img,bg='black')
        llb.place(x=0,y=0,width=1270,height=700)
        
        win.mainloop()
        
    def b():
        
        def info():
            messagebox.showinfo("Info","Created by RAJESH © 2022 All Rights Reserved",parent=win)
        
        win=Toplevel()

        win.geometry('1270x700+0+50')
        win.resizable(0,0)
        win.title('Contact info')
                
        imgf=Image.open('Contact.png')
        imgf=imgf.resize((1270,700))
        img=ImageTk.PhotoImage(imgf)
        llb=Label(win,image=img,bg='black')
        llb.place(x=0,y=0,width=1270,height=700)
        
        Button(llb,text='Info',command=info,font=('Open Sauce',10),height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white').place(x=1140,y=650)
        
        win.mainloop()
        
    def c():
        win=Toplevel()

        win.geometry('1270x700+0+50')
        win.resizable(0,0)
        win.title('Reviews')
                
        imgf=Image.open('Offers.png')
        imgf=imgf.resize((1270,700))
        img=ImageTk.PhotoImage(imgf)
        llb=Label(win,image=img,bg='black')
        llb.place(x=0,y=0,width=1270,height=700)
        
        signupbt=Button(llb,text='Sign up now!',command=Signup,font=('Open Sauce',15),height=1,width=15,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
        signupbt.place(x=810,y=470)
        
        win.mainloop()
    
    def d():
        win=Toplevel()

        win.geometry('1270x700+0+50')
        win.resizable(0,0)
        win.title('Reviews')
                
        imgf=Image.open('Book Now.png')
        imgf=imgf.resize((1270,700))
        img=ImageTk.PhotoImage(imgf)
        llb=Label(win,image=img,bg='black')
        llb.place(x=0,y=0,width=1270,height=700)
        
        signupbt=Button(llb,text='Book a flight',command=Signin,font=('Open Sauce',15),height=1,width=15,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
        signupbt.place(x=550,y=530)
        
        win.mainloop()
        
    
    win=Tk()

    win.geometry('1270x700+0+50')
    win.resizable(0,0)
    win.title('DeccanAir Airlines')
            
    imgf=Image.open('Blue Travel Offers & Deals Website.png')
    imgf=imgf.resize((1270,700))
    img=ImageTk.PhotoImage(imgf)
    llb=Label(win,image=img,bg='black')
    llb.place(x=0,y=0,width=1270,height=700)
    
    Button(llb,text='Top Destinations',command=d,font=('Open Sauce',10),height=1,width=15,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white').place(x=850,y=50)
    
    Button(llb,text='Offers',command=c,font=('Open Sauce',10),height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white').place(x=710,y=50)
    
    Button(llb,text='Customer Review',command=a,font=('Open Sauce',10),height=1,width=15,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white').place(x=550,y=50)
    
    Button(llb,text='Contact',command=b,font=('Open Sauce',10),height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white').place(x=1140,y=650)
    
    signinbt=Button(llb,text='Sign in',command=Signin,font=('Open Sauce',10),height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
    signinbt.place(x=1010,y=50)
    
    signupbt=Button(llb,text='Sign up',command=Signup,font=('Open Sauce',10),height=1,width=12,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
    signupbt.place(x=1150,y=50)
    
    bbt=Button(llb,text='Book a flight !',command=Signin,font=('Open Sauce',15),height=1,width=20,bg='#0080fe',fg='white',bd=0,activebackground='#00a2e4',activeforeground='white')
    bbt.place(x=520,y=440)
            
    win.mainloop()
    
Welcome()
#mainpg('raj@gmail.com')
#ticket('F001','Rajesh raj raj','7329245392',3,9000,'Chennai','Mumbai','12:00','19:00')
#ticketbooking('Mumbai','Chennai','F001','Rajesh','13:00','14:30',3000)