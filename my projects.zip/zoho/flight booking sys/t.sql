use DeccanAir;

CREATE table customer(Name varchar(35),F_no char(4),Fromplace varchar(30),Toplace Varchar(30),Takeoff_Time varchar(15),Landing_Time varchar(15),Aadhar_no varchar(25),No_of_seats int,Fare int,Total_fare int);

DESCRIBE customer;