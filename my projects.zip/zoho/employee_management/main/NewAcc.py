from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

class NewAccount:
    def __init__(self,root):
        self.root=root
        self.root.title('Creating New Account')
        self.root.geometry('1200x700+75+0')
        self.root.config(bg='#5B5B5B')
        self.root.resizable(0,0)

        #///////////////////////variables///////////////////////
        self.fstname=StringVar()
        self.secname=StringVar()
        self.Phno=StringVar()
        self.email=StringVar()
        self.SecQ=StringVar()
        self.SecA=StringVar()
        self.CreateP=StringVar()
        self.ConfirmP=StringVar()

        

        titlab=Label(self.root,text=('Empolyee Management Software'),font=('arobic',20,'bold'),background='#848484')
        titlab.pack()
        
        l1=Label(self.root,height=40,width=120,background='#848484')
        l1.place(x=187,y=50)

        nl=Label(self.root,text='New Account',font=('arobic',30,'bold'),background='#848484',fg='red',relief='raised')
        nl.place(x=490,y=60)

        #firstname
        fl=Label(self.root,text='First Name',font=('arobic',20,'bold'),background='#848484',fg='Black')
        fl.place(x=250,y=140)
        
        self.Fen=ttk.Entry(self.root,font=('arobic',20),textvariable=self.fstname)
        self.Fen.place(x=255,y=180)

        #secondname
        sl=Label(self.root,text='Second Name',font=('arobic',20,'bold'),background='#848484',fg='Black')
        sl.place(x=650,y=140)
        
        self.Sen=ttk.Entry(self.root,font=('arobic',20),textvariable=self.secname)
        self.Sen.place(x=655,y=180)

        #Phonenumber
        pl=Label(self.root,text='Phone Number',font=('arobic',20,'bold'),background='#848484',fg='Black')
        pl.place(x=250,y=240)
        
        self.Pen=ttk.Entry(self.root,font=('arobic',20),textvariable=self.Phno)
        self.Pen.place(x=255,y=280)

        #email
        El=Label(self.root,text='Email',font=('arobic',20,'bold'),background='#848484',fg='Black')
        El.place(x=650,y=240)
        
        self.Een=ttk.Entry(self.root,font=('arobic',20),textvariable=self.email)
        self.Een.place(x=655,y=280)

        #selct secu q
        ls=Label(self.root,text='Select Security Question',font=('arobic',20,'bold'),background='#848484',fg='Black')
        ls.place(x=250,y=340)
        
        self.cbb=ttk.Combobox(self.root,width=19,state='readonly',font=('arobic',20),textvariable=self.SecQ)
        self.cbb['values']=(
            'Select',
            "Your Childhood Friend name?",
            "Your Pet name?",
            "Place of birth?"
        )
        self.cbb.current(0)
        self.cbb.place(x=255,y=385)

        #sec_ans
        lsa=Label(self.root,text='Security Answer',font=('arobic',20,'bold'),background='#848484',fg='Black')
        lsa.place(x=650,y=340)

        self.sen=ttk.Entry(self.root,font=('arobic',20),textvariable=self.SecA)
        self.sen.place(x=655,y=385)

        #password1
        psl=Label(self.root,text='Create a Password',font=('arobic',20,'bold'),background='#848484',fg='Black')
        psl.place(x=250,y=450)

        self.psen1=ttk.Entry(self.root,font=('arobic',20),textvariable=self.CreateP)
        self.psen1.place(x=255,y=495)
        #confirm_pass
        cpsl=Label(self.root,text='Confirm Password',font=('arobic',20,'bold'),background='#848484',fg='Black')
        cpsl.place(x=650,y=450)

        self.cpsen1=ttk.Entry(self.root,font=('arobic',20),textvariable=self.ConfirmP)
        self.cpsen1.place(x=655,y=495)

        #submit button
        sbb=Button(self.root,text='Submit',bg='Red',fg='white',font=('arobic',20),command=self.submit)
        sbb.place(x=400,y=555)

        #loginbutton
        lbacc=Button(self.root,text='Login',bg='Red',fg='white',font=('arobic',20))
        lbacc.place(x=700,y=555)

    def submit(self):
        if self.fstname.get()=='' or self.secname.get()=='' or self.Phno.get()=='' or self.email.get()=='' or self.SecQ.get()=='Select' or self.SecA.get()=='':
            messagebox.showerror('Error!','All details are required to be filled')
        elif self.CreateP.get()=='' and self.ConfirmP.get()=='':
            messagebox.showerror('Error!','Create a password!')
        elif self.CreateP.get()!=self.ConfirmP.get():
            messagebox.showerror('Error!','Create password & Confirm password should be same')
        else:
            messagebox.showinfo('Account created','Successfully created an account')
            conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
            mcur=conn.cursor()
            q='select * from useraccounts where email=%s'
            val=(self.email.get(),)
            mcur.execute(q,val)
            row=mcur.fetchone()
            if row!=None:
                messagebox.showerror('Error','User already exist please try another email')
            else:
                mcur.execute(f"insert into useraccounts values('{self.fstname.get()}','{self.secname.get()}',{self.Phno.get()},'{self.email.get()}','{self.SecQ.get()}','{self.SecA.get()}','{self.ConfirmP.get()}')")
            conn.commit()
            conn.close()
            messagebox.showinfo('Account created','Successfully created an account')



root=Tk()
app=NewAccount(root)
root.mainloop()

#create table useraccounts(FirstName varchar(25),SecondName varchar(25),Phoneno varchar(13),Email varchar(50) PRIMARY KEY,SecurityQ varchar(50),SecurityA varchar(35),Passwd varchar(30)):