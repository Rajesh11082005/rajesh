from cgitb import reset
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from turtle import update
import mysql.connector

class Employee:
    def __init__(self,root):
        self.root=root
        self.root.state('zoomed')
        self.root.resizable(0,0)
        self.root.title('Empolyee Management System')
        self.root.config(bg='black')

        #+++++++++++++++++++++++++++++variables++++++++++++++++++++++++++++++++++++++++++++
        self.degi=StringVar()
        self.address=StringVar()
        self.datofbth=StringVar()
        self.idprfno=StringVar()
        self.name=StringVar()
        self.emal=StringVar()
        self.datofjoin=StringVar()
        self.phno=StringVar()
        self.countrynm=StringVar()
        self.salctc=StringVar()


        #title_label
        tlb=Label(self.root,text='Empolyee Management System',bg='black',font=('arobic',37,'bold'),fg='red',relief='ridge',)
        tlb.pack()

        #mainframelabel
        mfrlb=Label(self.root,bd=2,relief=RIDGE,bg='black')
        mfrlb.place(x=10,y=70,width=1350,height=310)

        #up_frame
        upfrlb=Label(self.root,bd=2,bg='black',text='Empolyee Information Enteries',font=('arobic',11,'bold'),fg='red')
        upfrlb.place(x=20,y=59)

        #lables and enteries under upper main frame

        #dept_lable
        deptlb=Label(mfrlb,text='Department',fg='white',font=('Arobic',16,'bold'),bg='black')
        deptlb.grid(row=0,column=0,padx=10,pady=15,sticky=W)

        #dept_entry_combox
        self.deptcmb=ttk.Combobox(mfrlb,font=('arobic',14,'bold'),width=20,state='readonly')
        self.deptcmb['value']=(
            'Select Department',
            'HR',
            'Product Development',
            'Sales',
            'Marketing',
            'Management',
            'Customer Care',
        )
        self.deptcmb.current(0)
        self.deptcmb.grid(row=0,column=1,padx=10,pady=15,sticky=W)

        #desg_lable
        desglb=Label(mfrlb,text='Designition',fg='white',font=('Arobic',16,'bold'),bg='black')
        desglb.grid(row=1,column=0,padx=10,pady=15,sticky=W)

        #desg_entry
        self.desgen=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.degi)
        self.desgen.grid(row=1,column=1,padx=10,pady=15,sticky=W)

        #address_lable
        addlb=Label(mfrlb,text='Address',fg='white',font=('Arobic',16,'bold'),bg='black')
        addlb.grid(row=2,column=0,padx=10,pady=15,sticky=W)

        #desg_entry
        self.adden=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.address)
        self.adden.grid(row=2,column=1,padx=10,pady=15,sticky=W)

        #dob_lable
        doblb=Label(mfrlb,text='Date Of Birth',fg='white',font=('Arobic',16,'bold'),bg='black')
        doblb.grid(row=3,column=0,padx=10,pady=15,sticky=W)

        #dob_entry
        self.doben=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.datofbth)
        self.doben.grid(row=3,column=1,padx=10,pady=15,sticky=W)

        #idproof_combox
        self.idcmb=ttk.Combobox(mfrlb,font=('arobic',14,'bold'),width=20,state='readonly')
        self.idcmb['value']=(
            'Select Id Proof',
            'Aadhar Card',
            'PAN Card',
            'Voter Id',
            'Driving Licence',
        )
        self.idcmb.current(0)
        self.idcmb.grid(row=4,column=0,padx=10,pady=15,sticky=W)

        #id_proof_entry
        self.iden=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.idprfno)
        self.iden.grid(row=4,column=1,padx=10,pady=15,sticky=W)

        #name_lable
        namelb=Label(mfrlb,text='Name',fg='white',font=('Arobic',16,'bold'),bg='black')
        namelb.grid(row=0,column=3,padx=10,pady=15,sticky=W)

        #name_entry
        self.nameen=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.name)
        self.nameen.grid(row=0,column=4,padx=10,pady=15,sticky=W)

        #email_lable
        emlb=Label(mfrlb,text='Email',fg='white',font=('Arobic',16,'bold'),bg='black')
        emlb.grid(row=1,column=3,padx=10,pady=15,sticky=W)

        #email_entry
        self.emen=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.emal)
        self.emen.grid(row=1,column=4,padx=10,pady=15,sticky=W)

        #doj_lable
        dojlb=Label(mfrlb,text='Date Of Joining',fg='white',font=('Arobic',16,'bold'),bg='black')
        dojlb.grid(row=2,column=3,padx=10,pady=15,sticky=W)

        #doj_entry
        self.dojen=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.datofjoin)
        self.dojen.grid(row=2,column=4,padx=10,pady=15,sticky=W)

        #gender_lable
        genlb=Label(mfrlb,text='Gender',fg='white',font=('Arobic',16,'bold'),bg='black')
        genlb.grid(row=3,column=3,padx=10,pady=15,sticky=W)

        #gender_combox
        self.gencmb=ttk.Combobox(mfrlb,font=('arobic',14,'bold'),width=20,state='readonly')
        self.gencmb['value']=(
            'Select Gender',
            'Male',
            'Female',
            'Others',
        )
        self.gencmb.current(0)
        self.gencmb.grid(row=3,column=4,padx=10,pady=15,sticky=W)

        #phno_lable
        phnolb=Label(mfrlb,text='Phone Number',fg='white',font=('Arobic',16,'bold'),bg='black')
        phnolb.grid(row=4,column=3,padx=10,pady=15,sticky=W)

        #phno_entry
        self.phnoen=Entry(mfrlb,font=('Arobic',16,'bold'),textvariable=self.phno)
        self.phnoen.grid(row=4,column=4,padx=10,pady=15,sticky=W)

        #country_lable
        ctlb=Label(mfrlb,text='Country',fg='white',font=('Arobic',14,'bold'),bg='black')
        ctlb.grid(row=0,column=5,padx=10,pady=15,sticky=W)

        #country_entry
        self.cten=Entry(mfrlb,font=('Arobic',14,'bold'),textvariable=self.countrynm)
        self.cten.grid(row=0,column=6,padx=10,pady=15,sticky=W)

        #salary_lable
        sallb=Label(mfrlb,text='Salary(CTC)',fg='white',font=('Arobic',14,'bold'),bg='black')
        sallb.grid(row=1,column=5,padx=9,pady=15,sticky=W)

        #salary_entry
        self.salen=Entry(mfrlb,font=('Arobic',14,'bold'),textvariable=self.salctc)
        self.salen.grid(row=1,column=6,padx=9,pady=15,sticky=W)

        #savebutton
        sbt=Button(mfrlb,text="Save",font=('Arobic',17,'bold'),bg='Green',width=10,border=5,command=self.add_data)
        sbt.place(x=1000,y=125)

        #Updatebutton
        sbt=Button(mfrlb,text="Update",font=('Arobic',17,'bold'),bg='Yellow',width=10,border=5,command=self.update_data)
        sbt.place(x=1180,y=125)

        #Deletebutton
        sbt=Button(mfrlb,text="Delete",font=('Arobic',17,'bold'),bg='Red',width=10,border=5,command=self.delete)
        sbt.place(x=1000,y=200)

        #Resetbutton
        sbt=Button(mfrlb,text="Reset",font=('Arobic',17,'bold'),bg='Blue',width=10,border=5,command=self.reset)
        sbt.place(x=1180,y=200)

        #lowermainframe
        mfrlb=Label(self.root,bd=2,relief=RIDGE,bg='black')
        mfrlb.place(x=10,y=400,width=1350,height=330)

        #down_frame
        dfrlb=Label(self.root,bd=2,bg='black',text='Empolyee Information ',font=('arobic',11,'bold'),fg='red')
        dfrlb.place(x=20,y=389)

        #down_search,frame
        seFrame=Label(self.root,bd=2,relief=RIDGE,bg='black')
        seFrame.place(x=25,y=420,width=1320,height=70)

        #text_down_frame
        dfrlb=Label(self.root,bd=2,bg='black',text='Empolyee Information Search',font=('arobic',11,'bold'),fg='red')
        dfrlb.place(x=40,y=410)

        #searchby_label
        serlb=Label(seFrame,text='Search By:',font=('arobic',15,'bold'),bg='Black',fg='orange')
        serlb.grid(row=0,column=0,padx=5,pady=10,sticky=W)

        #search_combox
        self.sercmb=ttk.Combobox(seFrame,font=('arobic',15,'bold'),width=20,state='readonly')
        self.sercmb['value']=(
            'Select Option',
            'Phoneno',
            'IdProof',
            'Email'
        )
        self.sercmb.current(0)
        self.sercmb.grid(row=0,column=1,padx=5,pady=10,sticky=W)

        #serach_entry
        self.seren=Entry(seFrame,font=('Arobic',14,'bold'))
        self.seren.grid(row=0,column=2,padx=5,pady=10,sticky=W)

        #search_button
        sbt=Button(seFrame,text="Search",font=('Arobic',15,'bold'),bg='red',width=10,border=5,command=self.search)
        sbt.grid(row=0,column=3,padx=5,pady=10,sticky=W)

        #showall_button
        sbt=Button(seFrame,text="Show All",font=('Arobic',15,'bold'),bg='red',width=10,border=5,command=self.fetch_data)
        sbt.grid(row=0,column=4,padx=5,pady=10,sticky=W)

        #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #emp_table

        #table_Frame
        tabFrame=Label(self.root,bd=2,relief=RIDGE,bg='black')
        tabFrame.place(x=25,y=490,width=1320,height=230)

        #scroll_bar
        scr_x=ttk.Scrollbar(tabFrame,orient=HORIZONTAL)
        scr_y=ttk.Scrollbar(tabFrame,orient=VERTICAL)

        self.em_table=ttk.Treeview(tabFrame,column=('dep',
                                                    'degi',
                                                    'address',
                                                    'dob',
                                                    'idproof',
                                                    'idproofno',
                                                    'name',
                                                    'email',
                                                    'doj',
                                                    'gender',
                                                    'phoneno',
                                                    'country',
                                                    'salary'),xscrollcommand=scr_x,yscrollcommand=scr_y)
        
        scr_x.pack(side=BOTTOM,fill=X)
        scr_y.pack(side=RIGHT,fill=Y)

        scr_x.config(command=self.em_table.xview)
        scr_y.config(command=self.em_table.yview)

        self.em_table.heading('dep',text='Department')
        self.em_table.heading('degi',text='Designition')
        self.em_table.heading('name',text='Name')
        self.em_table.heading('email',text='Email')
        self.em_table.heading('address',text='Address')
        self.em_table.heading('dob',text='Date Of Birth')
        self.em_table.heading('doj',text='Date Of Joining')
        self.em_table.heading('idproof',text='ID Type')
        self.em_table.heading('idproofno',text='ID Proof')
        self.em_table.heading('gender',text='Gender')
        self.em_table.heading('phoneno',text='Phone Number')
        self.em_table.heading('country',text='Country')
        self.em_table.heading('salary',text='Salary(CTC)')

        self.em_table['show']='headings'

        self.em_table.column('dep',width=100)
        self.em_table.column('degi',width=100)
        self.em_table.column('name',width=100)
        self.em_table.column('email',width=100)
        self.em_table.column('address',width=100)
        self.em_table.column('dob',width=100)
        self.em_table.column('doj',width=100)
        self.em_table.column('idproof',width=100)
        self.em_table.column('idproofno',width=100)
        self.em_table.column('gender',width=100)
        self.em_table.column('phoneno',width=100)
        self.em_table.column('country',width=100)
        self.em_table.column('salary',width=100)

        self.em_table.pack(fill=BOTH,expand=1)
        self.em_table.bind("<ButtonRelease>",self.get_data)
        self.fetch_data()


    #--------------------------functions-------------------------------

    #create table employee values(Department varchar(40),Designition varchar(40),Address varchar(60),DOB varchar(30),IDType varchar(25),IDProof varchar(25),Name varchar(25),Email varchar(40),DOJ varchar(30),Gender varchar(15),Phoneno varchar(25),Country varchar(30),Salary varchar(15));

    def add_data(self):
        if self.degi.get()=='' or self.address.get()==''or self.datofbth.get()==''or self.idprfno.get()==''or self.name.get()==''or self.emal.get()==''or self.datofjoin.get()==''or self.phnoen.get()==''or self.countrynm.get()=='' or self.salctc.get()=='' or self.deptcmb.get()=='Select Department' or self.idcmb.get()=='Select Id Proof' or self.gencmb.get()=='Select Gender':
            messagebox.showwarning('Alert','All details must be filled')
        else:
            try:
                conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                mcur=conn.cursor()
                mcur.execute('insert into employee values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',(
                                                                                                    self.deptcmb.get(),
                                                                                                    self.degi.get(),
                                                                                                    self.address.get(),
                                                                                                    self.datofbth.get(),
                                                                                                    self.idcmb.get(),
                                                                                                    self.idprfno.get(),
                                                                                                    self.name.get(),
                                                                                                    self.emal.get(),
                                                                                                    self.datofjoin.get(),
                                                                                                    self.gencmb.get(),
                                                                                                    self.phno.get(),
                                                                                                    self.countrynm.get(),
                                                                                                    self.salctc.get()
                                                                                                    ))
                conn.commit()
                conn.close()
                self.fetch_data()
                messagebox.showinfo('Success','Empolyee has been added',parent=self.root)
                self.reset()

                
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)

    #fetch_data
    def fetch_data(self):
        conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
        mcur=conn.cursor()
        mcur.execute('select * from employee')
        data=mcur.fetchall()
        if len(data)!=0:
            self.em_table.delete(*self.em_table.get_children())
            for i in data:
                self.em_table.insert('',END,values=i)
            conn.commit()
        conn.close()
    
    #get_data
    def get_data(self,event=''):
        cur_r=self.em_table.focus()
        content=self.em_table.item(cur_r)
        data=content['values']

        self.deptcmb.set(data[0])
        self.degi.set(data[1])
        self.address.set(data[2])
        self.datofbth.set(data[3])
        self.idcmb.set(data[4])
        self.idprfno.set(data[5]) 
        self.name.set(data[6])
        self.emal.set(data[7])
        self.datofjoin.set(data[8])
        self.gencmb.set(data[9])
        self.phno.set(data[10])
        self.countrynm.set(data[11])
        self.salctc.set(data[12])

    #update data
    def update_data(self):
        if self.degi.get()=='' or self.address.get()==''or self.datofbth.get()==''or self.idprfno.get()==''or self.name.get()==''or self.emal.get()==''or self.datofjoin.get()==''or self.phnoen.get()==''or self.countrynm.get()=='' or self.salctc.get()=='' or self.deptcmb.get()=='Select Department' or self.idcmb.get()=='Select Id Proof' or self.gencmb.get()=='Select Gender':
            messagebox.showwarning('Alert','All details must be filled')
        else:
            try:
                update=messagebox.askyesno('Update','Are you sure update this employee data')
                if update>0:
                    conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                    mcur=conn.cursor()
                    mcur.execute('update employee set Department=%s,Designition=%s,Address=%s,DOB=%s,IDType=%s,Name=%s,Email=%s,DOJ=%s,Gender=%s,Phoneno=%s,Country=%s,Salary=%s where IDProof=%s',(
                                                                                                                                                                                                    self.deptcmb.get(),
                                                                                                                                                                                                    self.degi.get(),
                                                                                                                                                                                                    self.address.get(),
                                                                                                                                                                                                    self.datofbth.get(),
                                                                                                                                                                                                    self.idcmb.get(),                                                                                                                                                                                                    self.name.get(),
                                                                                                                                                                                                    self.emal.get(),
                                                                                                                                                                                                    self.datofjoin.get(),
                                                                                                                                                                                                    self.gencmb.get(),
                                                                                                                                                                                                    self.phno.get(),
                                                                                                                                                                                                    self.countrynm.get(),
                                                                                                                                                                                                    self.salctc.get(),
                                                                                                                                                                                                    self.idprfno.get()
                                                                                                                                                                                                    ))
                else:
                    if not update:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo('Success','Employee Details successfully Updated',parent=self.root)
                self.reset()
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)

    #delete_data
    def delete(self):
        if self.degi.get()=='' or self.address.get()==''or self.datofbth.get()==''or self.idprfno.get()==''or self.name.get()==''or self.emal.get()==''or self.datofjoin.get()==''or self.phnoen.get()==''or self.countrynm.get()=='' or self.salctc.get()=='' or self.deptcmb.get()=='Select Department' or self.idcmb.get()=='Select Id Proof' or self.gencmb.get()=='Select Gender':
            messagebox.showwarning('Alert','All details must be filled')
        else:
            try:
                ask=messagebox.askyesno('Delete','Are you sure to delete this employee details',parent=self.root)
                if ask>0:
                    conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                    mcur=conn.cursor()
                    q=("delete from employee where IDProof=%s")
                    v=(self.idprfno.get(),)
                    mcur.execute(q,v)
                else:
                    if not ask:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                self.reset()
                messagebox.showinfo('Success','Employee Details successfully Deleted',parent=self.root)
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)
    
    #reset_datas
    def reset(self):
        self.deptcmb.current(0)
        self.degi.set('')
        self.address.set('')
        self.datofbth.set('')
        self.idcmb.current(0)
        self.idprfno.set('')
        self.name.set('')
        self.emal.set('')
        self.datofjoin.set('')
        self.gencmb.current(0)
        self.phno.set('')
        self.countrynm.set('')
        self.salctc.set('')

    #serach_data
    def search(self):
        if self.sercmb.get()=='' or self.seren.get()=='':
            messagebox.showerror('Error','Fill the details to search')
        else:
            try:
                conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                mcur=conn.cursor()
                mcur.execute('select * from employee where '+str(self.sercmb.get())+" like '%"+str(self.seren.get()+"%'"))
                r=mcur.fetchall()
                if len(r)!=0:
                    self.em_table.delete(*self.em_table.get_children())
                    for i in r:
                        self.em_table.insert("",END,values=i)
                    conn.commit()
                else:
                    self.em_table.delete(*self.em_table.get_children())
                    for i in range(13):
                        self.em_table.insert("",END,values='')
                    messagebox.showerror('Error',"No Data Found")
                    conn.close()
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)
    

win=Tk()
Employee(win)
win.mainloop()