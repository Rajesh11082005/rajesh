from time import strftime
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
#import mysql.connector
from PIL import Image,ImageTk

#pip install pillow

def mainfun():
    win=Tk()
    Login_window(win)
    win.mainloop()



class Login_window:

    def __init__(self,root):
        self.root=root
        self.root.title('LOGIN')
        self.root.geometry('950x500+100+60')
        self.root.config(bg='white')
        self.root.iconbitmap('employee_management//usericon.ico')
        self.root.resizable(0,0)
        self.user=StringVar()
        self.pas=StringVar()

        imgf=Image.open('employee_management//signinimg.jpg')
        imgf=imgf.resize((400,400))
        self.img=ImageTk.PhotoImage(imgf)
        Label(self.root,image=self.img,bg='white').place(x=50,y=50)

        #frame
        frame=Frame(self.root,width=400,height=400,bg='white')
        frame.place(x=500,y=50)

        logl=Label(frame,text="Sign in",font=('Microsoft YaHei UI Light',23,'bold'),fg='#57a1f8',bg='white')
        logl.place(x=150,y=5)

        #username
        def on_enter(e):
            if self.uEn.get()=='Username':
                self.uEn.delete(0,'end')
        
        def on_leave(e):
            name=self.uEn.get()
            if name=='':
                name=self.uEn.insert(0,'Username')


        self.uEn=Entry(frame,font=('Microsoft YaHei UI Light',11),textvariable=self.user,fg='black',border=0,bg='white',width=30)
        self.uEn.insert(0,'Username')
        self.uEn.place(x=70,y=80)
        self.uEn.bind('<FocusIn>',on_enter)
        self.uEn.bind('<FocusOut>',on_leave)

        Frame(frame,width=310,height=2,bg='black').place(x=65,y=107)

        #Password
        def on_enterr(e):
            if self.pEn.get()=='Password':
                self.pEn.delete(0,'end')
                submit()
            
        
        def on_leavee(e):
            name=self.pEn.get()
            if name=='':
                name=self.pEn.insert(0,'Password')
                submit()
                


        self.pEn=Entry(frame,font=('Microsoft YaHei UI Light',11),textvariable=self.pas,fg='black',border=0,bg='white',width=25)
        self.pEn.insert(0,'Password')
        self.pEn.place(x=70,y=150)
        self.pEn.bind('<FocusIn>',on_enterr)
        self.pEn.bind('<FocusOut>',on_leavee)

        def submit():
            if self.pEn.get()=='Password':
                self.pEn.config(show="")
            elif self.pEn.get()!='Password' and c1.get()==0:
                self.pEn.config(show="*")
            elif self.pEn.get()!='Password' and c1.get()==1:
                self.pEn.config(show="")
            


        Frame(frame,width=310,height=2,bg='black').place(x=65,y=177)
        c1=IntVar()
        ck1=Checkbutton(frame,text='Show password',font=('Microsoft YaHei UI Light',7),variable=c1,onvalue=1,offvalue=0,background='white',command=submit)
        ck1.place(y=150,x=290)


        #Login
        lbb=Button(frame,text='Sign in',bg='#57a1f8',fg='white',font=('Microsoft YaHei UI Light',11),command=self.login,border=0,pady=7,width=40)
        lbb.place(x=35,y=214)

        #creat_acc
        framlb=Label(frame,text="Don't have an account?",fg='black',bg='white',font=('Microsoft YaHei UI Light',10))
        framlb.place(x=104,y=280)

        abb=Button(frame,text='Sign up',bg='white',fg='#57a1f8',font=('Microsoft YaHei UI Light',10,'underline'),command=self.regwin,width=6,border=0,cursor='hand2')
        abb.place(x=247,y=278)

        #forgotpass
        fbb=Button(frame,text='Forgot password?',bg='white',fg='#57a1f8',font=('Microsoft YaHei UI Light',10,'underline'),command=self.forgotpass,width=13,border=0,cursor='hand2')
        fbb.place(x=104,y=300)

    def regwin(self):
        self.newwin=Toplevel(self.root)
        self.app=NewAccount(self.newwin)

    def login(self):
        if self.uEn.get()=='Username' or self.pEn.get()=='Password':
            messagebox.showerror('Error','Username or Password is unfilled!',parent=self.root)
        elif self.uEn.get().count('@')!=1:
            messagebox.showerror('Error','Invaild Username',parent=self.root)
        else:
            conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
            mcur=conn.cursor() 
            mcur.execute(f"select * from useraccounts where Email='{self.user.get()}' and Passwd='{self.pas.get()}'")
            r=mcur.fetchone()
            if r==None:
                messagebox.showerror('Error','Invalid Username and Password',parent=self.root)
            else:
                self.newwin=Toplevel(self.root)
                self.project=Employee(self.newwin) #main project open
            conn.commit()
            conn.close()
#---------------------------------resetpasswd-------------------------------------------------
    def reset(self):
        if self.fcbb.get()=='Select security question':
            messagebox.showerror('Error','Please Select Security Question',parent=self.root2)
        elif self.secAen.get()=='Security answer':
            messagebox.showerror('Error','Please Answer the security question',parent=self.root2)
        elif self.npen.get()=='New password':
            messagebox.showerror('Error','Please enter the new password',parent=self.root2)
        elif len(self.npen.get())<8:
            messagebox.showerror('Error','Please enter the password upto 8 characters',parent=self.root2)
        else:
            conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
            mcur=conn.cursor()
            q=("select * from useraccounts where Email=%s and SecurityQ=%s and SecurityA=%s")
            val=self.user.get(),self.fcbb.get(),self.secAen.get()
            mcur.execute(q,val)
            r=mcur.fetchone()
            if r==None:
                messagebox.showerror('Error','Please enter the correct answer',parent=self.root2)
            else:
                q=('update useraccounts set Passwd=%s where Email=%s')
                v=self.npen.get(),self.user.get()
                mcur.execute(q,v)
                conn.commit()
                conn.close()
                messagebox.showinfo('Info','Your new password has been updated successfully!',parent=self.root2)
                self.root2.destroy()


    
#-----------------------------------------------forgotpasswd------------------------------------------
    def forgotpass(self):
        if self.user.get()=='Username':
            messagebox.showerror('Error','Please enter the username to reset password!',parent=self.root)
        else:
            conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
            mcur=conn.cursor()
            q=(f"select * from useraccounts where Email='{self.user.get()}'")
            mcur.execute(q)
            r=mcur.fetchone()
            if r==None:
                messagebox.showerror('Error','Please enter the correct username!',parent=self.root)
            else:
                conn.close()
                self.root2=Toplevel()
                self.root2.resizable(0,0)
                self.root2.title('Forgot Password')
                self.root2.iconbitmap('employee_management//forgotpass.icopass.ico')
                self.root2.geometry('950x500+100+60')
                self.root2.config(bg='white')

                imgff=Image.open('employee_management//forgotpassimg.jpg')
                imgff=imgff.resize((400,400))
                self.img2=ImageTk.PhotoImage(imgff)
                Label(self.root2,image=self.img2,bg='white').place(x=50,y=50)

                frame2=Frame(self.root2,width=400,height=400,bg='white')
                frame2.place(x=500,y=50)

                #lable
                flb2=Label(frame2,text='Reset Password',fg='red',font=('Microsoft YaHei UI Light',23,'bold'),bg='white')
                flb2.place(x=95,y=5)

                #comboxquestions
                self.fcbb=ttk.Combobox(frame2,width=37,state='readonly',font=('Microsoft YaHei UI Light',11))
                self.fcbb['values']=(
                'Select security question',
                "Your Childhood Friend name?",
                "Your Pet name?",
                "Place of birth?"
                )
                self.fcbb.current(0)
                self.fcbb.place(x=65,y=80)
                #Frame(frame2,width=295,height=2,bg='black').place(x=65,y=107)
                

                #secAns entry
                def on_enter(e):
                    if self.secAen.get()=='Security answer':
                        self.secAen.delete(0,'end')
                    
                
                def on_leave(e):
                    name=self.secAen.get()
                    if name=='':
                        name=self.secAen.insert(0,'Security answer')

                self.secAen=Entry(frame2,font=('Microsoft YaHei UI Light',11),border=0,width=26)
                self.secAen.insert(0,'Security answer')
                self.secAen.place(x=70,y=150)
                self.secAen.bind('<FocusIn>',on_enter)
                self.secAen.bind('<FocusOut>',on_leave)

                Frame(frame2,width=320,height=2,bg='black').place(x=65,y=177)

                #new passwd entry
                def on_enterr(e):
                    if self.npen.get()=='New password':
                        self.npen.delete(0,'end')
                        submit1()
                    
                
                def on_leavee(e):
                    name=self.npen.get()
                    if name=='':
                        name=self.npen.insert(0,'New password')
                        submit1()
                        


                self.npen=Entry(frame2,font=('Microsoft YaHei UI Light',11),fg='black',border=0,bg='white',width=25)
                self.npen.insert(0,'New password')
                self.npen.place(x=70,y=220)
                self.npen.bind('<FocusIn>',on_enterr)
                self.npen.bind('<FocusOut>',on_leavee)

                def submit1():
                    if self.npen.get()=='New password':
                        self.npen.config(show="")
                    elif self.npen.get()!='New password' and c1.get()==0:
                        self.npen.config(show="*")
                    elif self.npen.get()!='New password' and c1.get()==1:
                        self.npen.config(show="")
                    


                Frame(frame2,width=320,height=2,bg='black').place(x=65,y=247)
                c1=IntVar()
                ck1=Checkbutton(frame2,text='Show password',font=('Microsoft YaHei UI Light',7),variable=c1,onvalue=1,offvalue=0,background='white',command=submit1)
                submit1()
                ck1.place(y=220,x=300)

                #reset  passwd  button
                rpb=Button(frame2,text='Reset password',bg='red',fg='white',font=('Microsoft YaHei UI Light',11),border=0,pady=7,width=40,command=self.reset)
                rpb.place(x=35,y=290)


class NewAccount:
    def __init__(self,root):
        self.root=root
        self.root.title('Creating New Account')
        self.root.geometry('1300x600+40+0')
        self.root.config(bg='white')
        self.root.resizable(0,0)
        self.root.iconbitmap('employee_management//emp.ico')


        #///////////////////////variables///////////////////////
        self.fstname=StringVar()
        self.email=StringVar()
        self.SecQ=StringVar()
        self.SecA=StringVar()
        self.CreateP=StringVar()
        self.ConfirmP=StringVar()

        

        imgff=Image.open('employee_management//signupimg.jpg')
        imgff=imgff.resize((450,450))
        self.img2=ImageTk.PhotoImage(imgff)
        Label(self.root,image=self.img2,bg='white').place(x=50,y=70)

        frame=Frame(self.root,width=700,height=500,background='white')
        frame.place(x=550,y=50)

        nl=Label(frame,text='Sign up',fg='#1fd655',font=('Microsoft YaHei UI Light',23,'bold'),bg='white')
        nl.place(x=300,y=5)

        #firstname
        def on_enter(e):
            if self.name.get()=='Name':
                self.name.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.name.get()
            if n=='':
                n=self.name.insert(0,'Name')

        self.name=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.fstname)
        self.name.insert(0,'Name')
        self.name.place(x=50,y=110)
        self.name.bind('<FocusIn>',on_enter)
        self.name.bind('<FocusOut>',on_leave)

        Frame(frame,width=310,height=2,bg='black').place(x=45,y=137)

        #email
        def on_enter(e):
            if self.emal.get()=='Email':
                self.emal.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.emal.get()
            if n=='':
                n=self.emal.insert(0,'Email')

        self.emal=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.email)
        self.emal.insert(0,'Email')
        self.emal.place(x=380,y=110)
        self.emal.bind('<FocusIn>',on_enter)
        self.emal.bind('<FocusOut>',on_leave)

        Frame(frame,width=310,height=2,bg='black').place(x=370,y=137)

        #selct secu q
        self.cbb=ttk.Combobox(frame,width=36,state='readonly',font=('Microsoft YaHei UI Light',11),textvariable=self.SecQ)
        self.cbb['values']=(
            'Select security question',
            "Your Childhood Friend name?",
            "Your Pet name?",
            "Place of birth?"
        )
        self.cbb.current(0)
        self.cbb.place(x=45,y=190)

        #sec_ans
        def on_enter(e):
            if self.sen.get()=='Security answer':
                self.sen.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.sen.get()
            if n=='':
                n=self.sen.insert(0,'Security answer')

        self.sen=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.SecA)
        self.sen.insert(0,'Security answer')
        self.sen.place(x=380,y=190)
        self.sen.bind('<FocusIn>',on_enter)
        self.sen.bind('<FocusOut>',on_leave)

        Frame(frame,width=310,height=2,bg='black').place(x=370,y=217)

        #password1
        def on_enter(e):
            if self.psen1.get()=='Create password':
                self.psen1.delete(0,'end')
                submit1()
                    
                
        def on_leave(e):
            n=self.psen1.get()
            if n=='':
                n=self.psen1.insert(0,'Create password')
                submit1()

        self.psen1=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.CreateP)
        self.psen1.insert(0,'Create password')
        self.psen1.place(x=50,y=270)
        self.psen1.bind('<FocusIn>',on_enter)
        self.psen1.bind('<FocusOut>',on_leave)

        Frame(frame,width=310,height=2,bg='black').place(x=45,y=297)

        def submit1():
            if self.psen1.get()=='Create password':
                self.psen1.config(show="")
            elif self.psen1.get()!='Create password' and c1.get()==0:    
                self.psen1.config(show="*")
            elif self.psen1.get()!='Create password' and c1.get()==1:
                self.psen1.config(show="")

        c1=IntVar()
        ck1=Checkbutton(frame,text='Show password',font=('Microsoft YaHei UI Light',7),variable=c1,onvalue=1,offvalue=0,background='white',command=submit1)
        submit1()
        ck1.place(x=270,y=270)
        #confirm_pass
        def on_enter(e):
            if self.cpsen1.get()=='Confirm password':
                self.cpsen1.delete(0,'end')
                submit2()
                    
                
        def on_leave(e):
            n=self.cpsen1.get()
            if n=='':
                n=self.cpsen1.insert(0,'Confirm password')
                submit2()

        self.cpsen1=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.ConfirmP)
        self.cpsen1.insert(0,'Confirm password')
        self.cpsen1.place(x=380,y=270)
        self.cpsen1.bind('<FocusIn>',on_enter)
        self.cpsen1.bind('<FocusOut>',on_leave)

        Frame(frame,width=310,height=2,bg='black').place(x=370,y=297)

        def submit2():
            if self.cpsen1.get()=='Confirm password':
                self.cpsen1.config(show="")
            elif self.cpsen1.get()!='Confirm password' and c2.get()==0:    
                self.cpsen1.config(show="*")
            elif self.cpsen1.get()!='Confirm password' and c2.get()==1:
                self.cpsen1.config(show="")

        c2=IntVar()
        ck2=Checkbutton(frame,variable=c2,text='Show password',font=('Microsoft YaHei UI Light',7),onvalue=1,offvalue=0,background='white',command=submit2)
        submit2()
        ck2.place(x=593,y=270)

        #submit button
        sbb=Button(frame,text='Submit',bg='#1fd655',fg='white',font=('Microsoft YaHei UI Light',11),border=0,pady=7,width=20,command=self.submit)
        sbb.place(x=100,y=355)

        #loginbutton
        lbacc=Button(frame,text='Sign in',bg='#1fd655',fg='white',font=('Microsoft YaHei UI Light',11),border=0,pady=7,width=20,command=self.log)
        lbacc.place(x=420,y=355)

    def submit(self):
        if self.fstname.get()=='Name' or self.email.get()=='Email' or self.SecQ.get()=='Select security question' or self.SecA.get()=='security answer':
            messagebox.showerror('Error!','All details are required to be filled',parent=self.root)
        elif self.CreateP.get()=='Create password' and self.ConfirmP.get()=='Confirm password':
            messagebox.showerror('Error!','Create a password!',parent=self.root)
        elif self.CreateP.get()!=self.ConfirmP.get():
            messagebox.showerror('Error!','Create password & Confirm password should be same',parent=self.root)
        elif len(self.CreateP.get())<8 :
            messagebox.showerror('Error!','Password should have minimum 8 characters',parent=self.root)
        elif self.email.get().count('@')!=1:
            messagebox.showerror('Error!','Invaild email',parent=self.root)
        else:
            messagebox.showinfo('Account created','Successfully created an account',parent=self.root)
            conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
            mcur=conn.cursor()
            q='select * from useraccounts where email=%s'
            val=(self.email.get(),)
            mcur.execute(q,val)
            row=mcur.fetchone()
            if row!=None:
                messagebox.showerror('Error','User already exist please try another email',parent=self.root)
            else:
                mcur.execute(f"insert into useraccounts values('{self.fstname.get()}','{self.email.get()}','{self.SecQ.get()}','{self.SecA.get()}','{self.ConfirmP.get()}')")
            conn.commit()
            conn.close()
            messagebox.showinfo('Account created','Successfully created an account',parent=self.root)

    def log(self):
        self.newwin=Toplevel(self.root)
        self.app=Login_window(self.newwin)

class Employee:
    def __init__(self,root):
        self.root=root
        self.root.state('zoomed')
        self.root.resizable(0,0)
        self.root.iconbitmap('employee_management//emp.ico')
        self.root.title('Empolyee Management Software')
        self.root.config(bg='white')

        #date_n_time_label
        dateandtimelb=Label(self.root,font=('Microsoft YaHei UI Light',11),bg='white',fg='orange')
        def time():
            st=strftime('%H:%M:%S %p \n %A %x')
            dateandtimelb.config(text=st)
            dateandtimelb.after(1000,time)
        dateandtimelb.place(x=10,y=10)
        time()
        #create table useraccounts(FirstName varchar(25),Email varchar(50) PRIMARY KEY,SecurityQ varchar(50),SecurityA varchar(35),Passwd varchar(30)):
        #create table employee(Department varchar(40),Designition varchar(40),Address varchar(60),IDType varchar(25),IDProof varchar(25),Name varchar(25),Email varchar(40),DOJ date,Gender varchar(15),Phoneno varchar(25)  PRIMARY KEY,Salary varchar(15));
        #+++++++++++++++++++++++++++++variables++++++++++++++++++++++++++++++++++++++++++++
        self.degi=StringVar()
        self.address=StringVar()
        self.idprfno=StringVar()
        self.name=StringVar()
        self.emal=StringVar()
        self.datofjoin=StringVar()
        self.phno=StringVar()
        self.salctc=StringVar()

        #frame
        frame=Frame(self.root,width=900,height=725,background='white')
        frame.place(x=470,y=10)

        imgf=Image.open('employee_management//emp.png')
        imgf=imgf.resize((470,480))
        self.img=ImageTk.PhotoImage(imgf)
        Label(self.root,image=self.img,bg='white').place(x=0,y=130)

        #title_label
        tlb=Label(frame,text='Empolyee Management Software',bg='white',font=('Microsoft YaHei UI Light',23,'bold'),fg='orange')
        tlb.place(y=10,x=210)

        #dept_entry_combox
        self.deptcmb=ttk.Combobox(frame,font=('Microsoft YaHei UI Light',10,),width=30,state='readonly')
        self.deptcmb['value']=(
            'Select Department',
            'HR',
            'Product Development',
            'Sales',
            'Marketing',
            'Management',
            'Customer Care',
        )
        self.deptcmb.current(0)
        self.deptcmb.place(x=40,y=80)

        #desg_entry
        #self.desgen
        def on_enter(e):
            if self.desgen.get()=='Desiginition':
                self.desgen.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.desgen.get()
            if n=='':
                n=self.desgen.insert(0,'Desiginition')

        self.desgen=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.degi)
        self.desgen.insert(0,'Desiginition')
        self.desgen.place(x=300,y=80)
        self.desgen.bind('<FocusIn>',on_enter)
        self.desgen.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=295,y=105)

        #desg_entry
        #self.adden,self.address
        def on_enter(e):
            if self.adden.get()=='Address':
                self.adden.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.adden.get()
            if n=='':
                n=self.adden.insert(0,'Address')

        self.adden=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.address)
        self.adden.insert(0,'Address')
        self.adden.place(x=600,y=80)
        self.adden.bind('<FocusIn>',on_enter)
        self.adden.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=595,y=105)

        #idproof_combox
        self.idcmb=ttk.Combobox(frame,font=('Microsoft YaHei UI Light',10),width=30,state='readonly')
        self.idcmb['value']=(
            'Select Id Proof',
            'Aadhar Card',
            'PAN Card',
            'Voter Id',
            'Driving Licence',
        )
        self.idcmb.current(0)
        self.idcmb.place(x=40,y=140)

        #id_proof_entry
        #self.iden,self.idprfno
        def on_enter(e):
            if self.iden.get()=='Id proof number':
                self.iden.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.iden.get()
            if n=='':
                n=self.iden.insert(0,'Id proof number')

        self.iden=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.idprfno)
        self.iden.insert(0,'Id proof number')
        self.iden.place(x=300,y=140)
        self.iden.bind('<FocusIn>',on_enter)
        self.iden.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=295,y=165)

        #name_entry
        #self.nameen,self.name
        def on_enter(e):
            if self.nameen.get()=='Name':
                self.nameen.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.nameen.get()
            if n=='':
                n=self.nameen.insert(0,'Name')

        self.nameen=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.name)
        self.nameen.insert(0,'Name')
        self.nameen.place(x=600,y=140)
        self.nameen.bind('<FocusIn>',on_enter)
        self.nameen.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=595,y=165)

        #email_entry
        #self.emen,self.emal
        def on_enter(e):
            if self.emen.get()=='Email':
                self.emen.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.emen.get()
            if n=='':
                n=self.emen.insert(0,'Email')

        self.emen=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.emal)
        self.emen.insert(0,'Email')
        self.emen.place(x=300,y=200)
        self.emen.bind('<FocusIn>',on_enter)
        self.emen.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=295,y=225)

        #doj_entry
        #self.dojen,self.datofjoin
        def on_enter(e):
            if self.dojen.get()=='Date of joining':
                self.dojen.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.dojen.get()
            if n=='':
                n=self.dojen.insert(0,'Date of joining')

        self.dojen=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.datofjoin)
        self.dojen.insert(0,'Date of joining')
        self.dojen.place(x=600,y=200)
        self.dojen.bind('<FocusIn>',on_enter)
        self.dojen.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=595,y=225)

        #gender_combox
        self.gencmb=ttk.Combobox(frame,font=('Microsoft YaHei UI Light',10),width=30,state='readonly')
        self.gencmb['value']=(
            'Select gender',
            'Male',
            'Female',
            'Others',
        )
        self.gencmb.current(0)
        self.gencmb.place(x=40,y=200)

        #phno_entry
        #self.phnoen,self.phno
        def on_enter(e):
            if self.phnoen.get()=='Phone number':
                self.phnoen.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.phnoen.get()
            if n=='':
                n=self.phnoen.insert(0,'Phone number')

        self.phnoen=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.phno)
        self.phnoen.insert(0,'Phone number')
        self.phnoen.place(x=170,y=260)
        self.phnoen.bind('<FocusIn>',on_enter)
        self.phnoen.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=165,y=285)

        #salary_entry
        #self.salen,self.salctc
        def on_enter(e):
            if self.salen.get()=='Salary (CTC)':
                self.salen.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.salen.get()
            if n=='':
                n=self.salen.insert(0,'Salary (CTC)')

        self.salen=Entry(frame,font=('Microsoft YaHei UI Light',11),border=0,textvariable=self.salctc)
        self.salen.insert(0,'Salary (CTC)')
        self.salen.place(x=470,y=260)
        self.salen.bind('<FocusIn>',on_enter)
        self.salen.bind('<FocusOut>',on_leave)

        Frame(frame,width=285,height=2,bg='black').place(x=465,y=285)

        #savebutton
        sbt=Button(frame,text="Save",bg='orange',fg='white',font=('Microsoft YaHei UI Light',11),border=0,pady=7,width=20,command=self.add_data)
        sbt.place(x=60,y=325)

        #Updatebutton
        sbt=Button(frame,text="Update",bg='orange',fg='white',font=('Microsoft YaHei UI Light',11),border=0,pady=7,width=20,command=self.update_data)
        sbt.place(x=260,y=325)

        #Deletebutton
        sbt=Button(frame,text="Delete",bg='orange',fg='white',font=('Microsoft YaHei UI Light',11),border=0,pady=7,width=20,command=self.delete)
        sbt.place(x=660,y=325)

        #Resetbutton
        sbt=Button(frame,text="Reset",bg='orange',fg='white',font=('Microsoft YaHei UI Light',11),border=0,pady=7,width=20,command=self.reset)
        sbt.place(x=460,y=325)

        seFrame=Frame(frame,width=870,height=340,bg='white')
        seFrame.place(x=20,y=380)

        #searchby_label
        serlb=Label(seFrame,text='Search By:',font=('Microsoft YaHei UI Light',17),bg='white',fg='orange')
        serlb.place(x=10,y=5)

        #search_combox
        self.sercmb=ttk.Combobox(seFrame,font=('Microsoft YaHei UI Light',11),width=20,state='readonly')
        self.sercmb['value']=(
            'Select Option',
            'Phoneno',
            'IdProof',
            'Email'
        )
        self.sercmb.current(0)
        self.sercmb.place(x=130,y=10)
        
        #serach_entry
        #self.seren
        def on_enter(e):
            if self.seren.get()=='Enter details':
                self.seren.delete(0,'end')
                    
                
        def on_leave(e):
            n=self.seren.get()
            if n=='':
                n=self.seren.insert(0,'Enter details')

        self.seren=Entry(seFrame,font=('Microsoft YaHei UI Light',11),border=0)
        self.seren.insert(0,'Enter details')
        self.seren.place(x=340,y=10)
        self.seren.bind('<FocusIn>',on_enter)
        self.seren.bind('<FocusOut>',on_leave)

        Frame(seFrame,width=240,height=2,bg='black').place(x=335,y=35)
        
        #search_button
        sbt=Button(seFrame,text="Search",bg='orange',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=10,command=self.search)
        sbt.place(x=600,y=5)
        
        #showall_button
        sbt=Button(seFrame,text="Show All",bg='orange',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=10,command=self.fetch_data)
        sbt.place(x=710,y=5)

        #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #emp_table

        #table_Frame
        tabFrame=Label(self.root,bd=2,relief=RIDGE,bg='white')
        tabFrame.place(x=480,y=440,width=880,height=290)

        #scroll_bar
        scr_x=ttk.Scrollbar(tabFrame,orient=HORIZONTAL)
        scr_y=ttk.Scrollbar(tabFrame,orient=VERTICAL)

        self.em_table=ttk.Treeview(tabFrame,column=('dep',
                                                    'degi',
                                                    'address',
                                                    'idproof',
                                                    'idproofno',
                                                    'name',
                                                    'email',
                                                    'doj',
                                                    'gender',
                                                    'phoneno',
                                                    'salary'),xscrollcommand=scr_x,yscrollcommand=scr_y)
        
        scr_x.pack(side=BOTTOM,fill=X)
        scr_y.pack(side=RIGHT,fill=Y)

        scr_x.configure(command=self.em_table.xview)
        scr_y.configure(command=self.em_table.yview)

        self.em_table.heading('dep',text='Department')
        self.em_table.heading('degi',text='Designition')
        self.em_table.heading('name',text='Name')
        self.em_table.heading('email',text='Email')
        self.em_table.heading('address',text='Address')
        self.em_table.heading('doj',text='Date Of Joining')
        self.em_table.heading('idproof',text='ID Type')
        self.em_table.heading('idproofno',text='ID Proof')
        self.em_table.heading('gender',text='Gender')
        self.em_table.heading('phoneno',text='Phone Number')
        self.em_table.heading('salary',text='Salary(CTC)')

        self.em_table['show']='headings'

        self.em_table.column('dep',width=70)
        self.em_table.column('degi',width=70)
        self.em_table.column('name',width=70)
        self.em_table.column('email',width=70)
        self.em_table.column('address',width=70)
        self.em_table.column('doj',width=70)
        self.em_table.column('idproof',width=70)
        self.em_table.column('idproofno',width=70)
        self.em_table.column('gender',width=70)
        self.em_table.column('phoneno',width=70)
        self.em_table.column('salary',width=70)

        self.em_table.pack(fill=BOTH,expand=1)
        self.em_table.bind("<ButtonRelease>",self.get_data)
        self.fetch_data()


    #--------------------------functions-------------------------------

    def add_data(self):
        if self.degi.get()=='' or self.address.get()==''or self.idprfno.get()==''or self.name.get()==''or self.emal.get()==''or self.datofjoin.get()==''or self.phnoen.get()=='' or self.salctc.get()=='' or self.deptcmb.get()=='Select Department' or self.idcmb.get()=='Select Id Proof' or self.gencmb.get()=='Select Gender':
            messagebox.showwarning('Alert','All details must be filled',parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                mcur=conn.cursor()
                mcur.execute('insert into employee values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',(
                                                                                                    self.deptcmb.get(),
                                                                                                    self.degi.get(),
                                                                                                    self.address.get(),
                                                                                                    self.idcmb.get(),
                                                                                                    self.idprfno.get(),
                                                                                                    self.name.get(),
                                                                                                    self.emal.get(),
                                                                                                    self.datofjoin.get(),
                                                                                                    self.gencmb.get(),
                                                                                                    self.phno.get(),
                                                                                                    self.salctc.get()
                                                                                                    ))
                conn.commit()
                conn.close()
                self.fetch_data()
                messagebox.showinfo('Success','Empolyee has been added',parent=self.root)
                self.reset()

                
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)

    #fetch_data
    def fetch_data(self):
        conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
        mcur=conn.cursor()
        mcur.execute('select * from employee')
        data=mcur.fetchall()
        if len(data)!=0:
            self.em_table.delete(*self.em_table.get_children())
            for i in data:
                self.em_table.insert('',END,values=i)
            conn.commit()
        conn.close()
    
    #get_data
    def get_data(self,event=''):
        cur_r=self.em_table.focus()
        content=self.em_table.item(cur_r)
        data=content['values']

        self.deptcmb.set(data[0])
        self.degi.set(data[1])
        self.address.set(data[2])
        self.idcmb.set(data[3])
        self.idprfno.set(data[4]) 
        self.name.set(data[5])
        self.emal.set(data[6])
        self.datofjoin.set(data[7])
        self.gencmb.set(data[8])
        self.phno.set(data[9])
        self.salctc.set(data[10])

    #update data
    def update_data(self):
        if self.degi.get()=='' or self.address.get()=='' or self.idprfno.get()==''or self.name.get()==''or self.emal.get()==''or self.datofjoin.get()==''or self.phnoen.get()=='' or self.salctc.get()=='' or self.deptcmb.get()=='Select Department' or self.idcmb.get()=='Select Id Proof' or self.gencmb.get()=='Select Gender':
            messagebox.showwarning('Alert','All details must be filled',parent=self.root)
        else:
            try:
                update=messagebox.askyesno('Update','Are you sure update this employee data',parent=self.root)
                if update>0:
                    conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                    mcur=conn.cursor()
                    mcur.execute('update employee set Department=%s,Designition=%s,Address=%s,IDType=%s,Name=%s,Email=%s,DOJ=%s,Gender=%s,Phoneno=%s,Salary=%s where  FirstName=%s or IDProof=%s',(
                                                                                                                                                                                self.deptcmb.get(),
                                                                                                                                                                                self.degi.get(),
                                                                                                                                                                                self.address.get(),
                                                                                                                                                                                self.idcmb.get(),
                                                                                                                                                                                self.idprfno.get(),
                                                                                                                                                                                self.name.get(),
                                                                                                                                                                                self.emal.get(),
                                                                                                                                                                                self.datofjoin.get(),
                                                                                                                                                                                self.gencmb.get(),
                                                                                                                                                                                self.phno.get(),
                                                                                                                                                                                self.salctc.get(),
                                                                                                                                                                                self.name.get(),
                                                                                                                                                                                self.idprfno.get() 
                                                                                                                                                                                ))
                else:
                    if not update:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo('Success','Employee Details successfully Updated',parent=self.root)
                self.reset()
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)

    #delete_data
    def delete(self):
        if self.degi.get()=='' or self.address.get()==''or self.idprfno.get()==''or self.name.get()==''or self.emal.get()==''or self.datofjoin.get()==''or self.phnoen.get()=='' or self.salctc.get()=='' or self.deptcmb.get()=='Select Department' or self.idcmb.get()=='Select Id Proof' or self.gencmb.get()=='Select Gender':
            messagebox.showwarning('Alert','All details must be filled',parent=self.root)
        else:
            try:
                ask=messagebox.askyesno('Delete','Are you sure to delete this employee details',parent=self.root)
                if ask>0:
                    conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                    mcur=conn.cursor()
                    q=("delete from employee where IDProof=%s")
                    v=(self.idprfno.get(),)
                    mcur.execute(q,v)
                else:
                    if not ask:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                self.reset()
                messagebox.showinfo('Success','Employee Details successfully Deleted',parent=self.root)
                self.fetch_data()
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)
    
    #reset_datas
    def reset(self):
        self.deptcmb.current(0)
        self.degi.set('Desiginition')
        self.address.set('Address')
        self.idcmb.current(0)
        self.idprfno.set('Id proof number')
        self.name.set('Name')
        self.emal.set('Email')
        self.datofjoin.set('Date of joining')
        self.gencmb.current(0)
        self.phno.set('Phone number')
        self.salctc.set('Salary (CTC)')
        self.fetch_data()

    #serach_data
    def search(self):

        if self.sercmb.get()=='' or self.seren.get()=='':
            messagebox.showerror('Error','Fill the details to search',parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host='localhost',user='root',password='root',database='empmanage')
                mcur=conn.cursor()
                mcur.execute('select * from employee where '+str(self.sercmb.get())+" like '%"+str(self.seren.get()+"%'"))
                r=mcur.fetchall()
                if len(r)!=0:
                    self.em_table.delete(*self.em_table.get_children())
                    for i in r:
                        self.em_table.insert("",END,values=i)
                    conn.commit()
                else:
                    self.em_table.delete(*self.em_table.get_children())
                    for i in range(13):
                        self.em_table.insert("",END,values='')
                    messagebox.showerror('Error',"No Data Found",parent=self.root)
                    conn.close()
            except Exception as E:
                messagebox.showerror('Error',f'Due To:{str(E)}',parent=self.root)

class Welcome:
    def __init__(self,win):

        self.win=win
        self.win.title('Welcome Page')
        self.win.geometry('1357x690+0+0')
        self.win.config(bg='white')
        self.win.iconbitmap('employee_management//usericon.ico')
        self.win.resizable(0,0)

        #title_lable
        lllb=Label(self.win,text='Empolyee Management Software',bg='white',font=('Microsoft YaHei UI Light',30,'bold'),fg='#f94449')
        lllb.place(x=370,y=30)

        def log():
            win1=Toplevel()
            Login_window(win1)
            win1.mainloop()

        def signup():
            win2=Toplevel()
            NewAccount(win2)
            win2.mainloop()
        
        def info():
            messagebox.showinfo("Info",'Created by RAJESH © 2022 All Rights Reserved',parent=self.win)
        #loginButton
        logbt=Button(self.win,text='Sign in',bg='#f94449',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=20,command=log)
        logbt.place(x=480,y=600)

        #signup
        sbt=Button(self.win,text='Sign up',bg='#f94449',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=20,command=signup)
        sbt.place(x=685,y=600)

        infob=Button(self.win,text='Info',bg='#f94449',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=10,command=info)
        infob.place(y=20,x=1250)


root=Tk()
imgf=Image.open('employee_management//welcomepg.png')
imgf=imgf.resize((470,480))
img=ImageTk.PhotoImage(imgf)
Label(root,image=img,bg='white').place(x=445,y=130)
Welcome(root)
root.mainloop()
r=0
