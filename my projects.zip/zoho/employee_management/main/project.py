from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from PIL import Image,ImageTk
class Welcome:
    def __init__(self,win):
        self.win=win
        self.win.title('Welcome Page')
        self.win.state('zoomed')
        self.win.config(bg='white')
        self.win.iconbitmap('C://Users//Ranjith A//Pictures//py_vs_code___//employee_management//usericon.ico')
        self.win.resizable(0,0)

        #title_lable
        lllb=Label(self.win,text='Empolyee Management Software',bg='white',font=('Microsoft YaHei UI Light',23,'bold'),fg='#f94449')
        lllb.place(x=440,y=30)
        '''def log():
            win1=Tk()
            Login_window(win1)
            win1.mainloop

        def signup():
            win2=Tk()
            NewAccount(win2)
            win2.mainloop'''
        
        def info():
            messagebox.showinfo("Info",'This Project is done by:\n\tRajesh P\n\tBooveshwaran T\n\tRakul K\n\tRohan',parent=win)
        #loginButton
        logbt=Button(self.win,text='Sign in',bg='#f94449',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=20)
        logbt.place(x=480,y=600)



        #signup
        sbt=Button(self.win,text='Sign up',bg='#f94449',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=20)
        sbt.place(x=685,y=600)

        infob=Button(self.win,text='Info',bg='#f94449',fg='white',font=('Microsoft YaHei UI Light',11),border=0,width=10,command=info)
        infob.place(y=20,x=1250)

root=Tk()
imgf=Image.open('employee_management\welcomepg.png')
imgf=imgf.resize((470,480))
img=ImageTk.PhotoImage(imgf)
Label(root,image=img,bg='white').place(x=445,y=130)
Welcome(root)
root.mainloop()