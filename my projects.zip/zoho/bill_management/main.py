from tkinter import *
from tkinter import ttk
from tkinter.font import BOLD
#import mysql.connector

def reset():
    e1.delete(0,END)
    e2.delete(0,END)
    e3.delete(0,END)
    e4.delete(0,END)
    e5.delete(0,END)
    e6.delete(0,END)
    e7.delete(0,END)

def total():

    try:
        a1=int(f1.get())
    except:
        a1=0
    try:
        a2=int(f2.get())
    except:
        a2=0
    try:
        a3=int(f3.get())
    except:
        a3=0
    try:
        a4=int(f4.get())
    except:
        a4=0
    try:
        a5=int(f5.get())
    except:
        a5=0
    try:
        a6=int(f6.get())
    except:
        a6=0
    try:
        a7=int(f7.get())
    except:
        a7=0
    
    c1=200*a1
    c2=150*a2
    c3=150*a3
    c4=70*a4
    c5=75*a5
    c6=90*a6
    c7=10*a7

    totcost=c1+c2+c3+c4+c5+c6+c7
    showbill="Rs."+str('%.2f'%totcost)
    tot.set(showbill)

    #create database Ichiraku;
    #use Ichiraku;
    #create table Shop(No int primary key,Item1 int,Item2 int,Item3 int,Item4 int,Item5 int,Item6 int,Item7 int,Total varchar(50));
    if sum((a1,a2,a3,a4,a5,a6,a7))!=0:
        conn=mysql.connector.connect(host='localhost',user='root',password='root',database='Ichiraku')
        mcur=conn.cursor()
        qu=('select * from Shop;')
        mcur.execute(qu)
        row=mcur.fetchall()
        if row==[]:
            q=('insert into Shop values(1,%s,%s,%s,%s,%s,%s,%s,%s);')
            val=(a1,a2,a3,a4,a5,a6,a7,tot.get())
            mcur.execute(q,val)
        else:
            q=('insert into Shop values(%s,%s,%s,%s,%s,%s,%s,%s,%s);')
            val=(row[-1][0]+1,a1,a2,a3,a4,a5,a6,a7,tot.get())
            mcur.execute(q,val)

        conn.commit()
        conn.close()

def show():
    root=Toplevel()
    root.geometry('1000x530+100+100')
    root.resizable(0,0)
    root.title('Ichiraku Database')
    Label(root,text='Ichiraku Ramen Shop Database',font=('Elephant',33),width=300,height=2,bg='white',fg='red').pack()
    
    #table
    tabFrame=Label(root,bd=2,relief=RIDGE,bg='white')
    tabFrame.place(x=0,y=130,width=1000,height=400)
    #scroll_bar
    scr_x=ttk.Scrollbar(tabFrame,orient=HORIZONTAL)
    scr_y=ttk.Scrollbar(tabFrame,orient=VERTICAL)
    shoptb=ttk.Treeview(tabFrame,column=('n',
                                        '1',
                                        '2',
                                        '3',
                                        '4',
                                        '5',
                                        '6',
                                        '7',
                                        't',),xscrollcommand=scr_x,yscrollcommand=scr_y)
      
    scr_x.pack(side=BOTTOM,fill=X)
    scr_y.pack(side=RIGHT,fill=Y)
    scr_x.configure(command=shoptb.xview)
    scr_y.configure(command=shoptb.yview)

    shoptb.heading('n',text='OrderNo.')
    shoptb.heading('1',text='Item1')
    shoptb.heading('2',text='Item2')
    shoptb.heading('3',text='Item3')
    shoptb.heading('4',text='Item4')
    shoptb.heading('5',text='Item5')
    shoptb.heading('6',text='Item6')
    shoptb.heading('7',text='Item7')
    shoptb.heading('t',text='Total')

    shoptb['show']='headings'

    shoptb.column('n',width=70)
    shoptb.column('1',width=70)
    shoptb.column('2',width=70)
    shoptb.column('3',width=70)
    shoptb.column('4',width=70)
    shoptb.column('5',width=70)
    shoptb.column('6',width=70)
    shoptb.column('7',width=70)
    shoptb.column('t',width=70)

    shoptb.pack(fill=BOTH,expand=1)

    conn=mysql.connector.connect(host='localhost',user='root',password='root',database='ichiraku')
    mcur=conn.cursor()
    mcur.execute('select * from shop')
    data=mcur.fetchall()
    if len(data)!=0:
        shoptb.delete(*shoptb.get_children())
        for i in data:
            shoptb.insert('',END,values=i)
        conn.commit()
    conn.close()
    


win=Tk()

win.geometry('1000x530+100+100')
win.resizable(0,0)
win.title('Bill Management')

Label(win,text='Ichiraku Ramen Shop',font=('Elephant',33),width=300,height=2,bg='white',fg='red').pack()

frame=Frame(win,width=1000,height=412,bg='white')
frame.place(x=0,y=118)

innerf1=Frame(frame,width=370,height=400,bg='lightgreen',highlightbackground='black',highlightthickness=2)
innerf1.place(x=5,y=7)

innerf2=Frame(frame,width=310,height=400,bg='lightpink',relief='raised',bd=5)
innerf2.place(x=380,y=7)

innerf3=Frame(frame,width=300,height=400,highlightbackground='black',highlightthickness=2,bg='lightblue')
innerf3.place(x=695,y=7)

Menulb=Label(innerf1,text='Menu',font=('Matura MT Script Capitals',30),bg='lightgreen',fg='black')
Menulb.place(x=120,y=10)

lstmenulb=Label(innerf1,text=('Naruto Chaso Ramen Bowl   Rs.200/-\nStewed Chicken Ramen Bowl  Rs.150/-\nSea Food Ramen Bowl         Rs.150/-\nFried Tofu                           Rs.70/-\nChicken Cutlet                       Rs.75/-\nGarlic Fish                          Rs.90/-\nChicken Soup                        Rs.100/-\n'))
lstmenulb.config(bg='lightgreen',fg='black',font=('Matura MT Script Capitals',14))
lstmenulb.place(x=10,y=100)

Label(innerf2,text='Naruto Chaso Ramen Bowl',font=('Matura MT Script Capitals',12),bg='lightpink',fg='black').place(x=10,y=10)

Label(innerf2,text='Stewed Chicken Ramen Bowl',font=('Matura MT Script Capitals',12),bg='lightpink',fg='black').place(x=10,y=60)

Label(innerf2,text='Sea Food Ramen Bowl',font=('Matura MT Script Capitals',12),bg='lightpink',fg='black').place(x=10,y=110)

Label(innerf2,text='Fried Tofu',font=('Matura MT Script Capitals',12),bg='lightpink',fg='black').place(x=10,y=160)

Label(innerf2,text='Chicken Cutlet',font=('Matura MT Script Capitals',12),bg='lightpink',fg='black').place(x=10,y=210)

Label(innerf2,text='Garlic Fish',font=('Matura MT Script Capitals',12),bg='lightpink',fg='black').place(x=10,y=260)

Label(innerf2,text='Chicken Soup',font=('Matura MT Script Capitals',12),bg='lightpink',fg='black').place(x=10,y=310)

f1=StringVar()
f2=StringVar()
f3=StringVar()
f4=StringVar()
f5=StringVar()
f6=StringVar()
f7=StringVar()
tot=StringVar()

e1=Entry(innerf2,font=('Aria',13,BOLD),textvariable=f1,bd=5,width=4)
e1.place(x=240,y=10)

e2=Entry(innerf2,font=('Aria',13,BOLD),textvariable=f2,bd=5,width=4)
e2.place(x=240,y=60)

e3=Entry(innerf2,font=('Aria',13,BOLD),textvariable=f3,bd=5,width=4)
e3.place(x=240,y=110)

e4=Entry(innerf2,font=('Aria',13,BOLD),textvariable=f4,bd=5,width=4)
e4.place(x=240,y=160)

e5=Entry(innerf2,font=('Aria',13,BOLD),textvariable=f5,bd=5,width=4)
e5.place(x=240,y=210)

e6=Entry(innerf2,font=('Aria',13,BOLD),textvariable=f6,bd=5,width=4)
e6.place(x=240,y=260)

e7=Entry(innerf2,font=('Aria',13,BOLD),textvariable=f7,bd=5,width=4)
e7.place(x=240,y=310)

resetbt=Button(innerf2,text='Reset',font=('Aria',10,BOLD),bd=5,width=10,height=1,command=reset)
resetbt.place(x=2,y=350)

totbt=Button(innerf2,text='Total',font=('Aria',10,BOLD),bd=5,width=10,height=1,command=total)
totbt.place(x=102,y=350)

showbt=Button(innerf2,text='Show',font=('Aria',10,BOLD),bd=5,width=10,height=1,command=show)
showbt.place(x=202,y=350)

billlb=Menulb=Label(innerf3,text='Bill',font=('Matura MT Script Capitals',30),fg='black',bg='lightblue')
Menulb.place(x=105,y=10)

lbtotal=Label(innerf3,text='Total',font=('Matura MT Script Capitals',23),width=13,fg='lightblue',bg='black')
lbtotal.place(x=0,y=70)

toten=Label(innerf3,text='Rs 00.00',fg='black',font=('Aria',20,BOLD),bd=6,width=15,relief='groove',bg='lightyellow',textvariable=tot)
tot.set('Rs 00.00')
toten.place(x=15,y=130)

'''imgf=Image.open('10336158_18514993.jpg')
imgf=imgf.resize((200,200))
img=ImageTk.PhotoImage(imgf)
Label(innerf3,image=img,bg='lightblue').place(x=45,y=185)'''


win.mainloop()
