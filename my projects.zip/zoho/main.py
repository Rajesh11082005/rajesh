'''def contstr(s:str):
    for i in range(len(s)+1):
        print(s[:i])

contstr('rajesh')'''